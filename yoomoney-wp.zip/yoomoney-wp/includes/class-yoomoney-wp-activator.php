<?php

/**
 * Fired during plugin activation
 *
 * @link       https://github.com/L0L1K1510/yoomoney-wp
 * @since      1.0.0
 *
 * @package    Yoomoney-WP
 * @subpackage Yoomoney-WP/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Yoomoney-WP
 * @subpackage Yoomoney-WP/includes
 * @author     Maxim <parkin01@inbox.ru>
 */
class yoomoney_wp_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
